
import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import ProfileSection from '@/components/ProfileSection';
import SubscriptionsSection from '@/components/SubscriptionsSection';
import ProjectsSection from '@/components/ProjectsSection';

const CustomerDashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [subscriptions, setSubscriptions] = useState([]);
  const [projects, setProjects] = useState([]);

  const fetchData = async () => {
    if (!user) return;
    
    setLoading(true);
    setError(null);
    
    try {
      // 1. Fetch Profile
      const { data: profileData, error: profileError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle(); // Use maybeSingle to avoid 406 error if no rows found
      
      if (profileError) throw profileError;
      
      // If no profile exists yet, that's okay, we'll create it on first edit.
      // Or we could auto-create one here. For now, just set state.
      setUserProfile(profileData || { user_id: user.id });

      // 2. Fetch Subscriptions
      const { data: subsData, error: subsError } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', user.id)
        .order('start_date', { ascending: false });

      if (subsError) throw subsError;
      setSubscriptions(subsData || []);

      // 3. Fetch Projects
      const { data: projData, error: projError } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (projError) throw projError;
      setProjects(projData || []);

    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      setError('Failed to load dashboard data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    } else if (user) {
      fetchData();
    }
  }, [user, authLoading, navigate]);

  if (authLoading || (loading && !userProfile)) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-orange-500 animate-spin" />
          <p className="text-gray-400">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-black pt-24 px-4 flex items-center justify-center">
        <div className="bg-gray-900 border border-red-900/50 rounded-xl p-8 max-w-md w-full text-center">
          <div className="w-12 h-12 bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-6 h-6 text-red-500" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Something went wrong</h2>
          <p className="text-gray-400 mb-6">{error}</p>
          <Button onClick={fetchData} className="bg-orange-500 hover:bg-orange-600">
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard | STRUCURE</title>
      </Helmet>

      <div className="min-h-screen bg-black pt-28 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Profile Header Section */}
          <ProfileSection userProfile={userProfile} setUserProfile={setUserProfile} />

          {/* Main Content Tabs */}
          <div className="bg-transparent">
            <Tabs defaultValue="overview" className="w-full space-y-8">
              <TabsList className="bg-gray-900 border border-gray-800 p-1">
                <TabsTrigger value="overview" className="data-[state=active]:bg-gray-800 data-[state=active]:text-white text-gray-400">Overview</TabsTrigger>
                <TabsTrigger value="subscriptions" className="data-[state=active]:bg-gray-800 data-[state=active]:text-white text-gray-400">Subscriptions</TabsTrigger>
                <TabsTrigger value="projects" className="data-[state=active]:bg-gray-800 data-[state=active]:text-white text-gray-400">Projects</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-8 animate-in fade-in-50 duration-500 slide-in-from-bottom-2">
                <section>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-white">Recent Subscriptions</h2>
                    <Button variant="link" className="text-orange-500 hover:text-orange-400" onClick={() => document.querySelector('[value="subscriptions"]').click()}>View All</Button>
                  </div>
                  <SubscriptionsSection subscriptions={subscriptions.slice(0, 3)} />
                </section>

                <section>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-white">Active Projects</h2>
                    <Button variant="link" className="text-orange-500 hover:text-orange-400" onClick={() => document.querySelector('[value="projects"]').click()}>View All</Button>
                  </div>
                  <ProjectsSection projects={projects.slice(0, 3)} />
                </section>
              </TabsContent>

              <TabsContent value="subscriptions" className="animate-in fade-in-50 duration-500 slide-in-from-bottom-2">
                 <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-white">Your Subscriptions</h2>
                  </div>
                <SubscriptionsSection subscriptions={subscriptions} />
              </TabsContent>

              <TabsContent value="projects" className="animate-in fade-in-50 duration-500 slide-in-from-bottom-2">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-white">Your Projects</h2>
                    <Button className="bg-orange-500 hover:bg-orange-600 text-white">New Project</Button>
                  </div>
                <ProjectsSection projects={projects} />
              </TabsContent>
            </Tabs>
          </div>

        </div>
      </div>
    </>
  );
};

export default CustomerDashboard;
