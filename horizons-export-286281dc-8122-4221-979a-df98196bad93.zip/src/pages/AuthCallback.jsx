
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AuthCallback = () => {
  const navigate = useNavigate();
  const [error, setError] = useState(null);

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        // Supabase often handles the hash parsing automatically in getSession if the URL contains tokens.
        // We verify if we have a valid session after landing here.
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();

        if (sessionError) throw sessionError;

        if (session) {
          // Successfully authenticated
          navigate('/dashboard');
        } else {
          // If no session found immediately, it might be due to hash parsing delay or invalid link.
          // Check for error parameters in URL manually as a fallback
          const params = new URLSearchParams(window.location.hash.substring(1));
          const errorDescription = params.get('error_description');
          
          if (errorDescription) {
            throw new Error(errorDescription);
          }
          
          // If we are here without a session and without explicit error, wait a moment or fail.
          // Usually getSession resolves correctly.
          throw new Error('Unable to verify authentication session. The link may be expired.');
        }
      } catch (err) {
        console.error("Auth Callback Error:", err);
        setError(err.message || "Authentication failed");
      }
    };

    handleAuthCallback();
  }, [navigate]);

  if (error) {
    return (
      <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center p-4">
        <div className="bg-gray-900 border border-red-900/50 rounded-xl p-8 max-w-md w-full text-center">
          <div className="w-12 h-12 bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-6 h-6 text-red-500" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Authentication Failed</h2>
          <p className="text-gray-400 mb-6">{error}</p>
          <Button onClick={() => navigate('/login')} className="bg-orange-500 hover:bg-orange-600">
            Back to Login
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center">
      <Loader2 className="w-12 h-12 text-orange-500 animate-spin mb-4" />
      <p className="text-gray-400 font-medium">Verifying your access...</p>
    </div>
  );
};

export default AuthCallback;
