
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Send, MessageSquare, FileText, Loader2, User } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient'; 

const ContactPage = () => {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '', 
    subject: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate required fields
    if (!formData.name.trim() || !formData.subject.trim() || !formData.message.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields so we can assist you better.",
        variant: "destructive",
      });
      return;
    }

    if (!currentUser?.email) {
       toast({
        title: "Authentication Error",
        description: "You must be logged in to send a message.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const payload = {
        user_id: currentUser.id,
        name: formData.name,
        email: currentUser.email, // Implicitly used from authenticated session
        subject: formData.subject,
        message: formData.message,
        created_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('contacts')
        .insert([payload]);

      if (error) throw error;

      toast({
        title: "Message Sent Successfully",
        description: "Our support team will review your inquiry and respond shortly.",
        className: "bg-green-600 border-green-700 text-white",
      });

      // Reset form
      setFormData({ 
        name: '', 
        subject: '', 
        message: '' 
      });

    } catch (err) {
      console.error("Submission error:", err);
      toast({
        title: "Submission Failed",
        description: err.message || "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Contact Support | STRUCURE</title>
      </Helmet>

      <div className="min-h-screen bg-gray-950 text-white font-sans selection:bg-orange-500/30">
        
        {/* Animated Background Elements */}
        <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-purple-600/20 blur-[120px] rounded-full mix-blend-screen opacity-50" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-orange-600/20 blur-[120px] rounded-full mix-blend-screen opacity-50" />
        </div>

        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen py-24 px-4 sm:px-6 lg:px-8">
          
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12 max-w-2xl"
          >
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-200 to-gray-400">
              How can we help?
            </h1>
            <p className="text-lg text-gray-400 leading-relaxed">
              Submit a ticket to our engineering team. We typically respond within 24 hours.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-full max-w-lg"
          >
            <div className="bg-gray-900/60 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden p-8 relative ring-1 ring-white/5">
              
              {/* Decorative top gradient line */}
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 to-purple-600" />

              <form onSubmit={handleSubmit} className="space-y-6">
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300 ml-1 flex items-center gap-2">
                    <User className="w-4 h-4 text-orange-500" /> Name
                  </label>
                  <Input
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Your Full Name"
                    className="bg-gray-800/50 border-gray-700/50 focus:border-orange-500/50 focus:ring-orange-500/20 text-white placeholder:text-gray-600 transition-all duration-300 hover:bg-gray-800/80"
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300 ml-1 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-orange-500" /> Subject
                  </label>
                  <Input
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="Brief summary of the issue"
                    className="bg-gray-800/50 border-gray-700/50 focus:border-orange-500/50 focus:ring-orange-500/20 text-white placeholder:text-gray-600 transition-all duration-300 hover:bg-gray-800/80"
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300 ml-1 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-orange-500" /> Message
                  </label>
                  <Textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Describe your question or issue in detail..."
                    className="min-h-[160px] bg-gray-800/50 border-gray-700/50 focus:border-orange-500/50 focus:ring-orange-500/20 text-white placeholder:text-gray-600 resize-none transition-all duration-300 hover:bg-gray-800/80"
                    disabled={isLoading}
                  />
                </div>

                <Button 
                  type="submit" 
                  disabled={isLoading}
                  className="w-full h-12 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 active:scale-[0.98]"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      Send Message
                      <Send className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ContactPage;
