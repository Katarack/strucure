
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Building2, LineChart, Shield, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HomePage = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: LineChart,
      title: 'Structural Analysis',
      description: 'Precise tools for structural analysis, based on recognized technical bibliography and industry standards.',
    },
    {
      icon: Building2,
      title: 'Structural Design',
      description: 'Programs focused on simple and precise structural design, facilitating methodology and ensuring reliable results.',
    },
    {
      icon: Shield,
      title: 'Safety and Reliability',
      description: 'The reliability of each calculation is based on technical standards and current regulations for structural safety.',
    },
    {
      icon: Zap,
      title: 'Efficiency and Clarity',
      description: 'Optimized solutions for clear and direct engineering, simplifying processes without compromising accuracy.',
    },
  ];

  const handleAnalysisClick = () => {
    navigate('/software-selector', { 
      state: { category: 'ANÁLISIS ESTRUCTURAL' } 
    });
  };

  const handleDesignClick = () => {
    navigate('/software-selector', { 
      state: { category: 'DISEÑO DE CONCRETO REFORZADO' } 
    });
  };

  return (
    <>
      <Helmet>
        <title>STRUCURE - Safety First</title>
        <meta name="description" content="Structural engineering software developed with a professional focus on safety." />
      </Helmet>

      <div className="min-h-screen bg-gray-950 pt-24">
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-orange-600/10 via-transparent to-orange-500/5"></div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 lg:pt-32 pb-20 lg:pb-32">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-8 leading-tight tracking-tight">
                STRUCURE
                <span className="block text-3xl md:text-4xl mt-4 bg-gradient-to-r from-orange-400 to-orange-600 bg-clip-text text-transparent font-light italic">
                  "Safety First"
                </span>
              </h1>
              
              <p className="text-xl md:text-2xl text-gray-400 mb-12 max-w-3xl mx-auto leading-relaxed font-light">
                Welcome to STRUCURE. Analysis and structural design programs based on technical bibliography, simple yet precise. Access professional tools for your structural projects.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button
                  onClick={() => navigate('/software-selector')}
                  className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-6 text-lg rounded-lg shadow-lg shadow-orange-500/20 transition-all duration-300 hover:shadow-orange-500/40 hover:scale-105"
                >
                  Explore Catalog
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-24 bg-gradient-to-b from-gray-950 to-gray-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Professional Focus
              </h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                Our tools are based on recognized technical bibliography, providing precise structural analysis and reliable structural design, maintaining simplicity in use without compromising result accuracy.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ y: -8 }}
                  className="bg-gray-900/50 p-8 rounded-xl border border-gray-800 hover:border-orange-500/30 transition-all duration-300"
                >
                  <div className="bg-orange-500/10 w-14 h-14 rounded-lg flex items-center justify-center mb-6">
                    <feature.icon className="w-7 h-7 text-orange-500" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                  <p className="text-gray-400 leading-relaxed text-sm">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Software Categories Section */}
        <section className="py-24 bg-gray-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Software Catalog
              </h2>
              <p className="text-gray-400 text-lg">
                Technical programs based on specialized bibliography for structural analysis and design
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-8">
              {/* Análisis Estructural (Left) */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-gray-800 to-gray-900 p-10 rounded-2xl border border-gray-700 hover:border-orange-500/40 transition-all duration-300 cursor-pointer group"
                onClick={handleAnalysisClick}
              >
                <h3 className="text-3xl font-bold text-white mb-2 group-hover:text-orange-500 transition-colors">Structural Analysis</h3>
                <div className="h-1 w-20 bg-orange-500 mb-6 group-hover:w-32 transition-all duration-300"></div>
                <p className="text-gray-400 mb-6 leading-relaxed">
                   Fundamental calculation tools based on technical bibliography to evaluate structural behavior with precision and rigor.
                </p>
                <Button 
                  variant="link" 
                  onClick={(e) => { e.stopPropagation(); handleAnalysisClick(); }}
                  className="text-orange-400 p-0 hover:text-orange-300"
                >
                  View analysis tools →
                </Button>
              </motion.div>

              {/* Diseño Estructural (Right) */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-gray-800 to-gray-900 p-10 rounded-2xl border border-gray-700 hover:border-orange-500/40 transition-all duration-300 cursor-pointer group"
                onClick={handleDesignClick}
              >
                <h3 className="text-3xl font-bold text-white mb-2 group-hover:text-orange-500 transition-colors">Structural Design</h3>
                <div className="h-1 w-20 bg-orange-500 mb-6 group-hover:w-32 transition-all duration-300"></div>
                <p className="text-gray-400 mb-6 leading-relaxed">
                  Comprehensive solutions for element sizing and verification, focused on strict regulatory compliance and guaranteeing safe results.
                </p>
                <Button 
                  variant="link" 
                  onClick={(e) => { e.stopPropagation(); handleDesignClick(); }}
                  className="text-orange-400 p-0 hover:text-orange-300"
                >
                  View design tools →
                </Button>
              </motion.div>
            </div>
          </div>
        </section>

        {/* CTA Section (now footer-like) */}
        <section className="py-12 bg-gray-950 border-t border-gray-900">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <p className="text-lg text-gray-400 mb-4">
                © 2026 STRUCURE. All rights reserved.
              </p>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;
