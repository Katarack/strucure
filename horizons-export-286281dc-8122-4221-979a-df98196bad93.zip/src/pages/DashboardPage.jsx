
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import ProfileSection from '@/components/ProfileSection';
import ProjectsSection from '@/components/ProjectsSection';
import SubscriptionsSection from '@/components/SubscriptionsSection';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const DashboardPage = () => {
  const { currentUser } = useAuth();
  const [userProfile, setUserProfile] = useState(null);
  const [projects, setProjects] = useState([]);
  const [subscriptions, setSubscriptions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!currentUser) return;
      
      setIsLoading(true);
      try {
        // Fetch Profile
        const { data: profile } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('user_id', currentUser.id)
          .single();
        
        if (profile) setUserProfile(profile);

        // Fetch Projects
        const { data: projectsData } = await supabase
          .from('projects')
          .select('*')
          .eq('user_id', currentUser.id)
          .order('created_at', { ascending: false });

        if (projectsData) setProjects(projectsData);

        // Fetch Subscriptions
        const { data: subsData } = await supabase
          .from('subscriptions')
          .select('*')
          .eq('user_id', currentUser.id);

        if (subsData) setSubscriptions(subsData);

      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, [currentUser]);

  return (
    <>
      <Helmet>
        <title>Dashboard | STRUCURE</title>
      </Helmet>

      <div className="min-h-screen bg-gray-950 pt-24 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-8">
          
          <ProfileSection userProfile={userProfile} setUserProfile={setUserProfile} />

          <Tabs defaultValue="projects" className="w-full">
            <TabsList className="bg-gray-900 border border-gray-800 mb-6">
              <TabsTrigger value="projects" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white text-gray-400">
                My Projects
              </TabsTrigger>
              <TabsTrigger value="subscriptions" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white text-gray-400">
                Subscriptions
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="projects" className="space-y-4">
              <ProjectsSection projects={projects} />
            </TabsContent>
            
            <TabsContent value="subscriptions" className="space-y-4">
              <SubscriptionsSection subscriptions={subscriptions} />
            </TabsContent>
          </Tabs>

        </div>
      </div>
    </>
  );
};

export default DashboardPage;
