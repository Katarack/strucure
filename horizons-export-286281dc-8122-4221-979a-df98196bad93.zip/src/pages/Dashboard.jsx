
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { getSoftwareById } from '@/data/softwareData';
import { Button } from '@/components/ui/button';
import { Plus, Rocket, Calendar, Activity } from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [subscriptions, setSubscriptions] = useState([]);

  useEffect(() => {
    // Load subscriptions from localStorage
    const stored = JSON.parse(localStorage.getItem('subscriptions') || '[]');
    const userSubs = stored.filter((sub) => sub.userId === user.id && sub.status === 'active');
    setSubscriptions(userSubs);
  }, [user]);

  const allSubscribedSoftware = subscriptions.flatMap((sub) =>
    sub.software.map((id) => getSoftwareById(id)).filter(Boolean)
  );

  const totalMonthly = subscriptions.reduce((sum, sub) => sum + sub.total, 0);

  return (
    <>
      <Helmet>
        <title>Dashboard - STRUCURE</title>
        <meta name="description" content="Manage your subscriptions and access your software" />
      </Helmet>

      <div className="min-h-screen bg-gray-950 py-12 px-4 pt-32">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12 border-b border-gray-800 pb-8"
          >
            <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
            <p className="text-gray-400">Comprehensive management of tools and subscriptions</p>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="grid md:grid-cols-3 gap-6 mb-12"
          >
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center">
                  <Activity className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Active Software</p>
                  <p className="text-white text-2xl font-bold">{allSubscribedSoftware.length}</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Monthly Investment</p>
                  <p className="text-white text-2xl font-bold">${totalMonthly.toFixed(2)}</p>
                </div>
              </div>
            </div>

            <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-orange-500/10 rounded-lg flex items-center justify-center">
                  <Rocket className="w-6 h-6 text-orange-500" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Account Status</p>
                  <p className="text-white text-xl font-bold">Up to date</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Actions & List */}
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-white">Subscribed Tools</h2>
                  <Button
                    onClick={() => navigate('/software-selector')}
                    variant="outline"
                    size="sm"
                    className="border-gray-700 hover:border-orange-500 hover:text-orange-400 text-gray-300"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add
                  </Button>
                </div>

                {allSubscribedSoftware.length > 0 ? (
                  <div className="space-y-4">
                    {allSubscribedSoftware.map((software) => (
                      <div
                        key={software.id}
                        className="bg-gray-900 rounded-xl border border-gray-800 p-6 hover:border-gray-700 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div>
                          <h3 className="text-lg font-bold text-white mb-1">{software.name}</h3>
                          <p className="text-gray-500 text-sm mb-2">{software.category}</p>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-500/10 text-green-500">
                            Active
                          </span>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-gray-400 font-medium text-sm hidden sm:block">${software.price.toFixed(2)}/mo</span>
                          <Button 
                            onClick={() => navigate('/software-access')}
                            className="bg-gray-800 hover:bg-gray-700 text-white border border-gray-700"
                          >
                            Access
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-gray-900/50 rounded-2xl border border-gray-800 border-dashed p-12 text-center">
                    <p className="text-gray-400 mb-6">No active subscriptions currently exist</p>
                    <Button
                      onClick={() => navigate('/software-selector')}
                      className="bg-orange-500 hover:bg-orange-600 text-white"
                    >
                      Explore Catalog
                    </Button>
                  </div>
                )}
              </motion.div>
            </div>

            <div className="lg:col-span-1">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="bg-gradient-to-b from-gray-900 to-gray-900/50 rounded-xl border border-gray-800 p-6"
              >
                <h3 className="text-lg font-bold text-white mb-4">Quick Access</h3>
                <p className="text-gray-400 text-sm mb-6">
                  Go to the access section to launch your applications.
                </p>
                <Button
                  onClick={() => navigate('/software-access')}
                  className="w-full bg-white text-gray-900 hover:bg-gray-200 font-semibold py-6"
                >
                  <Rocket className="w-5 h-5 mr-2" />
                  Launch Software
                </Button>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
