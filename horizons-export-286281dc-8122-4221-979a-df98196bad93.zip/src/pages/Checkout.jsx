
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { getSoftwareById, calculateTotal } from '@/data/softwareData';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { CreditCard, ArrowLeft, Check, ShieldCheck } from 'lucide-react';

const Checkout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [selectedSoftware, setSelectedSoftware] = useState([]);

  useEffect(() => {
    const softwareIds = location.state?.selectedSoftware || [];
    if (softwareIds.length === 0) {
      navigate('/software-selector');
      return;
    }
    setSelectedSoftware(softwareIds.map((id) => getSoftwareById(id)).filter(Boolean));
  }, [location, navigate]);

  const total = calculateTotal(selectedSoftware.map((s) => s.id));

  const handlePayment = async () => {
    setLoading(true);

    // Simulate payment processing
    setTimeout(() => {
      // Store subscription in localStorage
      const subscription = {
        userId: user.id,
        software: selectedSoftware.map((s) => s.id),
        total,
        createdAt: new Date().toISOString(),
        status: 'active',
        renewalDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      };

      const existingSubscriptions = JSON.parse(localStorage.getItem('subscriptions') || '[]');
      existingSubscriptions.push(subscription);
      localStorage.setItem('subscriptions', JSON.stringify(existingSubscriptions));

      toast({
        title: 'Subscription Activated!',
        description: 'Thank you for trusting STRUCURE.',
      });

      setTimeout(() => {
        navigate('/dashboard');
      }, 1500);
    }, 2000);
  };

  return (
    <>
      <Helmet>
        <title>Checkout - STRUCURE</title>
        <meta name="description" content="Complete your purchase and activate your subscription" />
      </Helmet>

      <div className="min-h-screen bg-gray-950 py-12 px-4 pt-32">
        <div className="max-w-5xl mx-auto">
          <Button
            onClick={() => navigate('/software-selector')}
            variant="ghost"
            className="mb-8 text-gray-400 hover:text-white hover:bg-gray-800"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Catalog
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl font-bold text-white mb-8">Finalize Subscription</h1>

            <div className="grid md:grid-cols-3 gap-8">
              {/* Order Summary */}
              <div className="md:col-span-2 space-y-6">
                <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
                  <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-orange-500" />
                    Plan Details
                  </h2>
                  <div className="space-y-4">
                    {selectedSoftware.map((software) => (
                      <div
                        key={software.id}
                        className="flex items-center justify-between p-4 bg-gray-950/50 rounded-lg border border-gray-800"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-8 h-8 bg-orange-500/10 rounded flex items-center justify-center border border-orange-500/20">
                            <Check className="w-4 h-4 text-orange-500" />
                          </div>
                          <div>
                            <p className="text-white font-medium">{software.name}</p>
                            <p className="text-gray-500 text-xs uppercase tracking-wider">{software.category}</p>
                          </div>
                        </div>
                        <p className="text-white font-medium">${software.price.toFixed(2)}<span className="text-gray-600 text-sm">/mo</span></p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Payment Summary */}
              <div className="md:col-span-1">
                <div className="bg-gray-900 rounded-xl border border-gray-800 p-6 sticky top-28">
                  <h2 className="text-lg font-bold text-white mb-6">Payment Summary</h2>
                  
                  <div className="space-y-4 mb-8">
                    <div className="flex justify-between text-gray-400 text-sm">
                      <span>Subtotal</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-gray-400 text-sm">
                      <span>Estimated Taxes</span>
                      <span>$0.00</span>
                    </div>
                    <div className="border-t border-gray-800 pt-4 mt-4">
                      <div className="flex justify-between items-end">
                        <span className="text-white font-medium">Total to Pay</span>
                        <div className="text-right">
                          <span className="text-3xl font-bold text-orange-500">${total.toFixed(2)}</span>
                          <span className="text-gray-500 text-xs block">billed monthly</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={handlePayment}
                    disabled={loading}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white py-6 rounded-lg font-semibold transition-all duration-300 shadow-lg shadow-orange-500/10 hover:shadow-orange-500/20 disabled:opacity-70 flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        Processing...
                      </>
                    ) : (
                      <>
                        <CreditCard className="w-5 h-5" />
                        Confirm and Pay
                      </>
                    )}
                  </Button>

                  <p className="text-gray-600 text-xs text-center mt-4 leading-relaxed">
                    By confirming, you accept the terms of service. The subscription will renew automatically every month.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Checkout;
