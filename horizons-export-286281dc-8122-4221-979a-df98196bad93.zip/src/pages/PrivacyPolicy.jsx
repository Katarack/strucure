
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Lock, Database, Eye, ShieldCheck, RefreshCw, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

const PrivacyPolicy = () => {
  const navigate = useNavigate();

  const sections = [
    {
      id: 1,
      title: "1. Introduction and Overview",
      content: "At STRUCTURE, we value and respect your privacy. This Privacy Policy describes how we collect, use, and protect the personal information you provide to us when using our engineering software platform. Our goal is to ensure transparency and security in handling your data while offering high-quality structural calculation tools.",
      icon: Lock
    },
    {
      id: 2,
      title: "2. Collection of Personal Data",
      content: "To provide our services, we collect limited and necessary information, including: personal identification data (name, email address), billing information (securely processed through third-party providers), and technical data about your device and connection to manage session security and license compliance.",
      icon: Database
    },
    {
      id: 3,
      title: "3. Use of Information",
      content: "The collected information is used exclusively to: (a) process your payments and activate your subscription, (b) authenticate your access to the platform, (c) provide technical support and customer service, (d) send you important notifications about service updates or changes to our terms, and (e) continuously improve the performance and functionality of our software.",
      icon: Eye
    },
    {
      id: 4,
      title: "4. Data Protection and Security",
      content: "We implement robust technical, administrative, and physical security measures designed to protect your personal information against unauthorized access, disclosure, alteration, or destruction. We use SSL/TLS encryption for data transmission and store information on secure servers with restricted access.",
      icon: ShieldCheck
    },
    {
      id: 5,
      title: "5. Changes to Policy",
      content: "We reserve the right to update this Privacy Policy periodically to reflect changes in our practices or legal requirements. Any substantial change will be notified through the platform or by email before it takes effect. We recommend reviewing this page regularly.",
      icon: RefreshCw
    },
    {
      id: 6,
      title: "6. Contact",
      content: "If you have any questions, concerns, or requests regarding this Privacy Policy or the handling of your personal data, please do not hesitate to contact us through our contact form or by sending a direct email to privacy@structure.com.",
      icon: Mail
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <>
      <Helmet>
        <title>Privacy Policy - STRUCURE</title>
        <meta name="description" content="STRUCURE privacy policy and data protection. Learn how we manage and protect your information." />
      </Helmet>

      <div className="min-h-screen bg-gray-950 pt-24 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <Button 
              variant="ghost" 
              onClick={() => navigate(-1)}
              className="text-gray-400 hover:text-white hover:bg-gray-900 group pl-0"
            >
              <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
              Back
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Privacy Policy
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Your privacy is fundamental to us. Below we detail how we protect and manage your information.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-8"
          >
            {sections.map((section) => (
              <motion.section
                key={section.id}
                variants={itemVariants}
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 hover:border-blue-500/20 transition-all duration-300"
              >
                <div className="flex items-start gap-6">
                  <div className="hidden sm:flex flex-shrink-0 w-12 h-12 rounded-xl bg-blue-500/10 items-center justify-center">
                    <section.icon className="w-6 h-6 text-blue-500" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                      <span className="sm:hidden text-blue-500">
                        <section.icon className="w-6 h-6" />
                      </span>
                      {section.title}
                    </h2>
                    <p className="text-gray-400 leading-relaxed text-lg">
                      {section.content}
                    </p>
                  </div>
                </div>
              </motion.section>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.6 }}
            className="mt-16 text-center pt-8 border-t border-gray-800"
          >
            <p className="text-gray-500 text-sm">
              Last updated: January 2026
            </p>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default PrivacyPolicy;
