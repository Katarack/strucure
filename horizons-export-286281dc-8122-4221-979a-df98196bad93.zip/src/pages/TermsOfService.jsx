
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Shield, CreditCard, AlertTriangle, Copyright, MonitorX } from 'lucide-react';
import { Button } from '@/components/ui/button';

const TermsOfService = () => {
  const navigate = useNavigate();

  const sections = [
    {
      id: 1,
      title: "1. Access to Services",
      content: "Users have the right to unlimited access and use of all software programs and tools for which they have paid the corresponding subscription. Access is guaranteed immediately upon payment confirmation and remains active while the subscription is valid.",
      icon: Shield
    },
    {
      id: 2,
      title: "2. Cancellation and Refunds",
      content: "You maintain total control of your subscription and can cancel it at any time through your user panel. However, please note that we do not offer total or partial refunds for billing periods already started or for services not used before the end of the current billing cycle.",
      icon: CreditCard
    },
    {
      id: 3,
      title: "3. Responsibility of Use",
      content: "STRUCURE provides calculation tools based on recognized technical standards. However, the company is not responsible for the misuse of the software, incorrect interpretation of results, or errors derived from inaccurate input data. It is the sole responsibility of the engineer or professional in charge to verify the suitability and correctness of the results for each specific project.",
      icon: AlertTriangle
    },
    {
      id: 4,
      title: "4. Intellectual Property",
      content: "All programs, algorithms, source codes, designs, and interfaces contained in this platform are developed by and are the exclusive property of STRUCTURE. The use of our services does not grant the user any intellectual property rights over the software, beyond the personal and non-transferable use license granted during the subscription.",
      icon: Copyright
    },
    {
      id: 5,
      title: "5. Security and Single Access",
      content: "To protect the integrity of your account and prevent unauthorized use, access to the platform is strictly limited to a single device simultaneously. The system will automatically close previous sessions if a new login is detected. Sharing access credentials is prohibited and may result in permanent account suspension to prevent unauthorized resale or distribution of the service.",
      icon: MonitorX
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <>
      <Helmet>
        <title>Terms of Service - STRUCURE</title>
        <meta name="description" content="Terms and conditions of use for STRUCURE's structural engineering software services." />
      </Helmet>

      <div className="min-h-screen bg-gray-950 pt-24 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <Button 
              variant="ghost" 
              onClick={() => navigate(-1)}
              className="text-gray-400 hover:text-white hover:bg-gray-900 group pl-0"
            >
              <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
              Back
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Terms of Service
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Please read the following conditions governing the use of our structural engineering tools carefully.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-8"
          >
            {sections.map((section) => (
              <motion.section
                key={section.id}
                variants={itemVariants}
                className="bg-gray-900/50 border border-gray-800 rounded-2xl p-8 hover:border-orange-500/20 transition-all duration-300"
              >
                <div className="flex items-start gap-6">
                  <div className="hidden sm:flex flex-shrink-0 w-12 h-12 rounded-xl bg-orange-500/10 items-center justify-center">
                    <section.icon className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4 flex items-center gap-3">
                      <span className="sm:hidden text-orange-500">
                        <section.icon className="w-6 h-6" />
                      </span>
                      {section.title}
                    </h2>
                    <p className="text-gray-400 leading-relaxed text-lg">
                      {section.content}
                    </p>
                  </div>
                </div>
              </motion.section>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.6 }}
            className="mt-16 text-center pt-8 border-t border-gray-800"
          >
            <p className="text-gray-500 text-sm">
              Last updated: January 2026
            </p>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default TermsOfService;
