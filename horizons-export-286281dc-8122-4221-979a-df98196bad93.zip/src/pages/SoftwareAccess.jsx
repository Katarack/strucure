
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { getSoftwareById } from '@/data/softwareData';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, Play, Calendar, AlertTriangle } from 'lucide-react';

const SoftwareAccess = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [subscribedSoftware, setSubscribedSoftware] = useState([]);

  useEffect(() => {
    // Load user's subscribed software
    const subscriptions = JSON.parse(localStorage.getItem('subscriptions') || '[]');
    const userSubs = subscriptions.filter((sub) => sub.userId === user.id && sub.status === 'active');
    
    const softwareList = userSubs.flatMap((sub) =>
      sub.software.map((id) => {
        const software = getSoftwareById(id);
        return software ? { ...software, renewalDate: sub.renewalDate } : null;
      }).filter(Boolean)
    );

    setSubscribedSoftware(softwareList);
  }, [user]);

  const handleLaunch = (softwareName) => {
    toast({
      title: 'Starting secure environment...',
      description: `Establishing connection with ${softwareName}.`,
    });
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <>
      <Helmet>
        <title>My Tools - STRUCURE</title>
        <meta name="description" content="Access your subscribed software" />
      </Helmet>

      <div className="min-h-screen bg-gray-950 py-12 px-4 pt-32">
        <div className="max-w-7xl mx-auto">
          <Button
            onClick={() => navigate('/dashboard')}
            variant="ghost"
            className="mb-8 text-gray-400 hover:text-white hover:bg-gray-800"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>

          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12"
          >
            <h1 className="text-3xl font-bold text-white mb-4">Workspace</h1>
            <p className="text-gray-400 text-lg">
              Secure execution of engineering applications
            </p>
          </motion.div>

          {subscribedSoftware.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {subscribedSoftware.map((software, index) => (
                <motion.div
                  key={software.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-gray-900 rounded-xl border border-gray-800 p-8 hover:border-orange-500/30 transition-all duration-300 group flex flex-col h-full"
                >
                  <div className="flex-grow">
                    <div className="flex items-start justify-between mb-4">
                      <h2 className="text-xl font-bold text-white group-hover:text-orange-400 transition-colors">
                        {software.name}
                      </h2>
                      <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
                    </div>
                    <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-3">{software.category}</p>
                    <p className="text-gray-400 text-sm leading-relaxed mb-6">{software.description}</p>
                  </div>

                  <div className="mt-auto">
                    <div className="flex items-center gap-2 text-gray-500 text-xs mb-6 bg-gray-950/50 p-3 rounded border border-gray-800">
                      <Calendar className="w-3 h-3" />
                      <span>License valid until: {formatDate(software.renewalDate)}</span>
                    </div>

                    <Button
                      onClick={() => handleLaunch(software.name)}
                      className="w-full bg-white text-gray-900 hover:bg-gray-200 py-6 rounded-lg font-semibold transition-all duration-300 shadow-lg shadow-white/5 hover:shadow-white/10 flex items-center justify-center gap-2 group-hover:scale-[1.02]"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      Run
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="bg-gray-900 rounded-2xl border border-gray-800 p-16 text-center max-w-2xl mx-auto"
            >
              <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertTriangle className="w-10 h-10 text-orange-500" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-4">
                No software available
              </h2>
              <p className="text-gray-400 mb-8 max-w-md mx-auto">
                To access the workspace, you must first subscribe to one of our professional tools.
              </p>
              <Button
                onClick={() => navigate('/software-selector')}
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-6"
              >
                Go to Catalog
              </Button>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
};

export default SoftwareAccess;
