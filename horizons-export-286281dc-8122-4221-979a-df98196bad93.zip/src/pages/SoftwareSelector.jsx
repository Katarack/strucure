
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  catalogStructure, 
  getSoftwaresBySubcategory, 
  calculateTotal 
} from '@/data/softwareData';
import SoftwareCard from '@/components/SoftwareCard';
import { Button } from '@/components/ui/button';
import { ShoppingCart, ArrowRight, Construction, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

const SoftwareSelector = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [selectedSoftware, setSelectedSoftware] = useState([]);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState(null);

  // Translation mapping for legacy Spanish filters coming from HomePage
  const categoryMapping = {
    'ANÁLISIS ESTRUCTURAL': 'STRUCTURAL ANALYSIS',
    'DISEÑO DE CONCRETO REFORZADO': 'REINFORCED CONCRETE DESIGN',
    'DISEÑO ACERO ESTRUCTURAL (AISC360)': 'STRUCTURAL STEEL DESIGN (AISC360)'
  };

  useEffect(() => {
    if (location.state?.category) {
      const incomingCategory = location.state.category;
      // Use mapping if available, otherwise use original (assuming it's already English)
      setActiveCategoryFilter(categoryMapping[incomingCategory] || incomingCategory);
    }
  }, [location.state]);

  const toggleSoftware = (id) => {
    setSelectedSoftware((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const clearFilter = () => {
    setActiveCategoryFilter(null);
    window.history.replaceState({}, document.title);
  };

  const total = calculateTotal(selectedSoftware);

  const handleCheckout = () => {
    if (selectedSoftware.length > 0) {
      if (user) {
        navigate('/checkout', { state: { selectedSoftware } });
      } else {
        navigate('/login', { state: { from: location.pathname } });
      }
    }
  };

  const renderSection = (categoryTitle, sub, isNested = false) => {
    const items = getSoftwaresBySubcategory(categoryTitle, sub.id);
    const isGeneral = sub.id === 'General';

    // Determine if the orange dot should be shown
    const showOrangeDot = isNested && !(categoryTitle === 'REINFORCED CONCRETE DESIGN' && sub.id.startsWith('Losa_'));

    return (
      <div key={sub.id} className={`relative ${isNested ? 'mb-12 last:mb-0' : 'mb-12'}`}>
        {!isGeneral && (
          <h3 className={`text-xl font-semibold mb-6 transition-colors ${
            isNested 
              ? 'flex items-center gap-3 text-lg text-gray-300 ml-6' 
              : 'text-gray-300 pl-6 border-l-2 border-gray-800'
          }`}>
            {showOrangeDot && <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>}
            {sub.name}
          </h3>
        )}
        
        {items.length > 0 ? (
          <div className={`grid md:grid-cols-2 lg:grid-cols-3 gap-8 ${isNested ? 'pl-11' : 'pl-6'}`}>
            {items.map((software) => (
              <SoftwareCard
                key={software.id}
                software={software}
                isSelected={selectedSoftware.includes(software.id)}
                onToggle={toggleSoftware}
              />
            ))}
          </div>
        ) : (
          <div className={`bg-gray-900/40 border border-gray-800 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center group hover:border-gray-700 transition-colors ${
            isNested ? 'ml-11' : 'ml-6'
          }`}>
            <div className="p-3 bg-gray-900 rounded-full mb-4 group-hover:bg-gray-800 transition-colors">
              <Construction className="w-8 h-8 text-gray-600 group-hover:text-orange-500/70 transition-colors" />
            </div>
            <h4 className="text-gray-300 font-medium mb-2">Section Under Development</h4>
            <p className="text-gray-500 max-w-md text-sm">
              We are working hard to bring new tools for <span className="text-orange-500/80">{sub.name}</span>.
            </p>
          </div>
        )}
      </div>
    );
  };

  const displayedCatalog = activeCategoryFilter
    ? catalogStructure.filter(cat => cat.title === activeCategoryFilter)
    : catalogStructure;

  return (
    <>
      <Helmet>
        <title>Select Software - STRUCURE</title>
        <meta name="description" content="Select the software you need and create your personalized subscription" />
      </Helmet>

      <div className="min-h-screen bg-gray-950 py-12 px-4 pt-32">
        <div className="max-w-7xl mx-auto pb-24">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Subscription Configuration
            </h1>
            <p className="text-gray-400 text-lg mb-6">
              Select the specialized tools required for your projects
            </p>

            <AnimatePresence>
              {activeCategoryFilter && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="flex justify-center"
                >
                  <Button 
                    variant="outline" 
                    onClick={clearFilter}
                    className="flex items-center gap-2 border-orange-500/30 bg-orange-500/10 text-orange-400 hover:bg-orange-500/20 hover:text-orange-300"
                  >
                    Filtered by: {activeCategoryFilter}
                    <X className="w-4 h-4" />
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {displayedCatalog.length > 0 ? (
            displayedCatalog.map((category, catIndex) => (
              <motion.section
                key={category.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 * (catIndex + 1) }}
                className="mb-20"
              >
                {/* Main Category Header */}
                <div className="flex items-center gap-4 mb-10 pb-4 border-b border-gray-800/50">
                  <div className="w-1.5 h-10 bg-gradient-to-b from-orange-500 to-orange-600 rounded-full shadow-[0_0_10px_rgba(249,115,22,0.5)]"></div>
                  <h2 className="text-2xl font-bold text-white tracking-wide">
                    {category.title}
                  </h2>
                </div>

                {/* Subcategories */}
                <div className="space-y-4">
                  {category.subcategories.map((sub) => {
                    if (sub.isGroup) {
                      return (
                        <div key={sub.name} className="mt-8 mb-8">
                          {/* Group Header styled consistently with regular subcategories */}
                          <h3 className="text-xl font-semibold mb-8 text-gray-300 pl-6 border-l-2 border-gray-800">
                            {sub.name}
                          </h3>
                          
                          <div className="space-y-8 ml-0">
                            {sub.items.map((nestedSub) => renderSection(category.title, nestedSub, true))}
                          </div>
                        </div>
                      );
                    }
                    return renderSection(category.title, sub);
                  })}
                </div>
              </motion.section>
            ))
          ) : (
            <div className="text-center text-gray-400 py-20">
              <p>No categories found.</p>
              <Button onClick={clearFilter} variant="link" className="text-orange-400">
                View full catalog
              </Button>
            </div>
          )}

          {/* Checkout Summary Footer */}
          <motion.div
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="fixed bottom-0 left-0 right-0 z-40 bg-gray-900/95 backdrop-blur-md border-t border-gray-800 shadow-[0_-5px_20px_rgba(0,0,0,0.5)]"
          >
            <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="text-center md:text-left">
                <p className="text-gray-400 text-xs uppercase tracking-wider font-semibold mb-1">Selection Summary</p>
                <div className="flex items-baseline gap-2 justify-center md:justify-start">
                   <span className="text-white text-2xl font-bold">
                    {selectedSoftware.length}
                  </span>
                   <span className="text-gray-500 text-sm">
                    {selectedSoftware.length === 1 ? 'program selected' : 'programs selected'}
                   </span>
                </div>
              </div>
              
              <div className="flex items-center gap-6 md:gap-8 w-full md:w-auto justify-between md:justify-end">
                <div className="text-right">
                  <p className="text-gray-400 text-xs uppercase tracking-wider font-semibold mb-1">Monthly Total</p>
                  <p className="text-orange-500 text-2xl font-bold tracking-tight">${total.toFixed(2)}</p>
                </div>
                
                <Button
                  onClick={handleCheckout}
                  disabled={selectedSoftware.length === 0}
                  className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-6 rounded-lg font-semibold transition-all duration-300 shadow-lg shadow-orange-500/20 disabled:opacity-50 disabled:shadow-none flex items-center gap-2"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span className="hidden sm:inline">
                    {user ? 'Proceed to Checkout' : 'Login to Checkout'}
                  </span>
                  <ArrowRight className="w-5 h-5 ml-1" />
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default SoftwareSelector;
