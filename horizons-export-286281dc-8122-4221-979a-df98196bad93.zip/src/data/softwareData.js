
export const softwareList = [
  {
    id: 'analysis_articulado_plano',
    name: 'Plane Truss',
    category: 'STRUCTURAL ANALYSIS',
    subcategory: 'General',
    price: 3.00,
    description: 'Analysis of 2D articulated structures.',
    features: ['Linear static analysis', 'Reaction calculation', 'Axial force diagrams']
  },
  {
    id: 'analysis_articulado_3d',
    name: '3D Truss',
    category: 'STRUCTURAL ANALYSIS',
    subcategory: 'General',
    price: 4.00,
    description: 'Analysis of 3D articulated structures.',
    features: ['Spatial analysis', 'Free rotational degrees of freedom', 'Nodal loads']
  },
  {
    id: 'analysis_viga',
    name: 'Beam',
    category: 'STRUCTURAL ANALYSIS',
    subcategory: 'General',
    price: 3.00,
    description: 'Beam Analysis',
    features: ['Multiple supports', 'Distributed and point loads', 'Shear and moment diagrams']
  },
  {
    id: 'analysis_viga_elastico',
    name: 'Beam on Elastic Foundation',
    category: 'STRUCTURAL ANALYSIS',
    subcategory: 'General',
    price: 4.00,
    description: 'Analysis of beams on elastic foundation (Winkler model).',
    features: ['Modulus of subgrade reaction', 'Settlements', 'Soil-structure interaction']
  },
  {
    id: 'analysis_portico_plano',
    name: 'Plane Frame',
    category: 'STRUCTURAL ANALYSIS',
    subcategory: 'General',
    price: 4.00,
    description: 'Analysis of 2D rigid frames.',
    features: ['Lateral displacements', 'Bending moments', 'Deflection']
  },
  {
    id: 'analysis_portico_3d',
    name: '3D Frame',
    category: 'STRUCTURAL ANALYSIS',
    subcategory: 'General',
    price: 5.00,
    description: 'Analysis of 3D rigid frames.',
    features: ['6 degrees of freedom per node', 'Torsion', 'Loads in any direction']
  },
  {
    id: 'concrete_beam_simple_tension',
    name: 'Singly Reinforced Beam',
    category: 'REINFORCED CONCRETE DESIGN',
    subcategory: 'Beam',
    price: 2.00,
    description: 'Calculates simple flexural design for reinforced concrete beams considering only tension reinforcement.',
    features: ['ACI 318 compliance', 'Single reinforcement', 'Strength design method']
  },
  {
    id: 'concrete_beam_compression',
    name: 'Doubly Reinforced Beam',
    category: 'REINFORCED CONCRETE DESIGN',
    subcategory: 'Beam',
    price: 3.00,
    description: 'Analyzes and designs reinforced concrete beams with both tension and compression reinforcement.',
    features: ['Doubly reinforced sections', 'Ductility verification', 'Long-term deflection control']
  },
  {
    id: 'concrete_beam_shear',
    name: 'Shear Design with Stirrups',
    category: 'REINFORCED CONCRETE DESIGN',
    subcategory: 'Beam',
    price: 2.50,
    description: 'Shear design for beams including vertical stirrup spacing and capacity calculations.',
    features: ['Shear diagram integration', 'Vs and Vc calculation', 'Spacing requirements']
  },
  {
    id: 'concrete_beam_deflection',
    name: 'Deflection Verification',
    category: 'REINFORCED CONCRETE DESIGN',
    subcategory: 'Beam',
    price: 0,
    description: 'Calculates immediate and long-term deflections for reinforced concrete beams.',
    features: ['Serviceability limit states', 'Cracked section analysis', 'Long-term deflection factors']
  }
];

export const catalogStructure = [
  {
    title: 'STRUCTURAL ANALYSIS',
    subcategories: [
      { name: 'General', id: 'General' }
    ]
  },
  {
    title: 'REINFORCED CONCRETE DESIGN',
    subcategories: [
      { name: 'Beam', id: 'Beam' },
      { name: 'Column', id: 'Column' },
      { name: 'Footing', id: 'Footing' },
      { name: 'Shear Wall', id: 'Shear Wall' },
      { name: 'Retaining Wall', id: 'Retaining Wall' },
      {
        name: 'Slab',
        isGroup: true,
        items: [
          { name: 'One-way Solid Slab', id: 'Losa_Maciza_1D' },
          { name: 'One-way Ribbed Slab', id: 'Losa_Aligerada_1D' },
          { name: 'Two-way Solid Slab', id: 'Losa_Maciza_2D' },
          { name: 'Two-way Ribbed Slab', id: 'Losa_Aligerada_2D' }
        ]
      }
    ]
  },
  {
    title: 'STRUCTURAL STEEL DESIGN (AISC360)',
    subcategories: [
      { name: 'General', id: 'General' }
    ]
  }
];

export const getSoftwareById = (id) => {
  return softwareList.find((software) => software.id === id);
};

export const getSoftwaresByCategory = (category) => {
  return softwareList.filter((software) => software.category === category);
};

export const getSoftwaresBySubcategory = (category, subcategory) => {
  // Map legacy subcategory IDs if necessary, or ensure softwareList uses the same IDs
  // For this implementation, softwareList subcategories are mostly 'General' or 'Beam'.
  // The 'Slab' subcategories in catalogStructure use IDs like 'Losa_Maciza_1D', 
  // but we don't have those softwares in the list yet. 
  // The logic below matches strictly by string.
  return softwareList.filter((software) => 
    software.category === category && software.subcategory === subcategory
  );
};

export const calculateTotal = (selectedIds) => {
  return selectedIds.reduce((total, id) => {
    const software = getSoftwareById(id);
    return total + (software?.price || 0);
  }, 0);
};
