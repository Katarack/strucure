
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { User, LogOut, Briefcase, Edit2 } from 'lucide-react';
import EditProfileModal from './EditProfileModal';

const ProfileSection = ({ userProfile, setUserProfile }) => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleLogout = async () => {
    await signOut();
    navigate('/login');
  };

  const handleProfileUpdate = (updatedProfile) => {
    setUserProfile(updatedProfile);
  };

  return (
    <>
      <div className="bg-gray-900 border border-gray-800 rounded-xl shadow-lg p-6 md:p-8">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 flex items-center justify-center shadow-xl border-4 border-gray-900">
              <span className="text-3xl font-bold text-white">
                {userProfile?.full_name ? userProfile.full_name.charAt(0).toUpperCase() : user?.email?.charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="absolute bottom-0 right-0 w-6 h-6 bg-green-500 rounded-full border-2 border-gray-900" title="Online"></div>
          </div>

          <div className="flex-1 text-center md:text-left space-y-2">
            <h2 className="text-2xl font-bold text-white">
              {userProfile?.full_name || 'Welcome!'}
            </h2>
            <div className="flex flex-col md:flex-row items-center gap-4 text-gray-400 text-sm">
              <span className="flex items-center gap-2">
                <User className="w-4 h-4" />
                {user?.email}
              </span>
              {userProfile?.company && (
                <span className="hidden md:block text-gray-600">•</span>
              )}
              {userProfile?.company && (
                <span className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  {userProfile.company}
                </span>
              )}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto mt-4 md:mt-0">
            <Button
              onClick={() => setIsModalOpen(true)}
              variant="outline"
              className="border-gray-700 bg-gray-900/50 text-gray-300 hover:text-white hover:bg-gray-800"
            >
              <Edit2 className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
            <Button
              onClick={handleLogout}
              variant="destructive"
              className="bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>

      <EditProfileModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        userProfile={{ ...userProfile, user_id: user?.id }}
        onProfileUpdate={handleProfileUpdate}
      />
    </>
  );
};

export default ProfileSection;
