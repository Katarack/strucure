
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

const Logo = () => {
  const navigate = useNavigate();

  return (
    <motion.div 
      onClick={() => navigate('/')}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      // Removed border, shadow, and overflow-hidden to display logo cleanly
      className="cursor-pointer z-50 flex items-center h-20 w-auto"
    >
      <img 
        src="https://horizons-cdn.hostinger.com/286281dc-8122-4221-979a-df98196bad93/b92bb3402a236d05c106cb92d23f009e.jpg" 
        alt="STRUCURE Logo" 
        className="h-full w-auto object-contain"
      />
    </motion.div>
  );
};

export default Logo;
