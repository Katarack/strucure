
import React from 'react';
import { Folder, Clock, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const ProjectsSection = ({ projects }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'completed':
        return 'bg-gray-800 text-gray-400 border-gray-700';
      case 'on-hold':
        return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
      default:
        return 'bg-gray-800 text-gray-400 border-gray-700';
    }
  };

  if (!projects || projects.length === 0) {
    return (
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-8 text-center">
        <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
          <Folder className="w-8 h-8 text-gray-600" />
        </div>
        <h3 className="text-lg font-semibold text-white mb-2">No projects found</h3>
        <p className="text-gray-400 text-sm max-w-md mx-auto mb-6">
          Start creating your engineering projects to track them here.
        </p>
        <Button variant="outline" className="border-gray-700 text-gray-300">
          Create New Project
        </Button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {projects.map((project, index) => (
        <motion.div
          key={project.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:shadow-xl hover:border-gray-700 transition-all duration-300 group flex flex-col h-full"
        >
          <div className="flex justify-between items-start mb-3">
            <h3 className="text-lg font-bold text-white group-hover:text-orange-400 transition-colors line-clamp-1">
              {project.name}
            </h3>
            <span
              className={cn(
                "px-2.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider border",
                getStatusColor(project.status)
              )}
            >
              {project.status}
            </span>
          </div>

          <p className="text-gray-400 text-sm mb-6 line-clamp-2 flex-grow">
            {project.description || "No description provided."}
          </p>

          <div className="mt-auto pt-4 border-t border-gray-800 flex items-center justify-between">
            <span className="text-xs text-gray-500 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              {new Date(project.created_at).toLocaleDateString()}
            </span>
            
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-orange-500 hover:text-orange-400 hover:bg-orange-500/10 p-0 h-auto font-medium"
            >
              View Details <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default ProjectsSection;
