
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { LogIn, LogOut, User, FileText, Mail, Shield, LayoutDashboard } from 'lucide-react';
import { motion } from 'framer-motion';
import Logo from '@/components/Logo';

const Header = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, signOut } = useAuth();

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  const isAuthPage = location.pathname === '/login' || location.pathname === '/signup';

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 bg-black border-b border-gray-800 h-24 shadow-lg shadow-black/50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center justify-between">
        {/* Logo Area */}
        <div className="flex-shrink-0 cursor-pointer" onClick={() => navigate('/')}>
          <Logo />
        </div>

        {/* Navigation & Auth Status Area */}
        {!isAuthPage && (
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Public Navigation Links */}
            <div className="hidden md:flex items-center gap-2 mr-2">
              <Button
                variant="ghost"
                onClick={() => navigate('/software-selector')}
                className="text-gray-400 hover:text-white hover:bg-gray-900 text-sm"
              >
                Products
              </Button>
              <Button
                variant="ghost"
                onClick={() => navigate('/terms-of-service')}
                className="text-gray-400 hover:text-white hover:bg-gray-900 text-sm"
              >
                Terms
              </Button>

              <Button
                variant="ghost"
                onClick={() => navigate('/contact')}
                className="text-gray-400 hover:text-white hover:bg-gray-900 text-sm"
              >
                Contact
              </Button>
            </div>

            {user ? (
              <div className="flex items-center gap-4">
                {/* Authenticated Links */}
                <Button
                  variant="ghost"
                  onClick={() => navigate('/dashboard')}
                  className="hidden sm:flex text-gray-300 hover:text-white hover:bg-gray-900 gap-2"
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </Button>

                <div className="hidden lg:flex flex-col items-end mr-2">
                  <span className="text-sm text-gray-400">Welcome,</span>
                  <span className="text-sm font-medium text-orange-400 max-w-[150px] truncate">
                    {user.email}
                  </span>
                </div>
                
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                  className="bg-black border-gray-700 hover:border-red-500 hover:text-red-400 text-gray-300 transition-colors hidden sm:flex"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
                
                <div 
                  onClick={() => navigate('/dashboard')}
                  className="w-10 h-10 bg-orange-500/10 rounded-full flex items-center justify-center border border-orange-500/20 cursor-pointer hover:bg-orange-500/20 transition-colors"
                >
                  <User className="w-5 h-5 text-orange-500" />
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <Button
                  onClick={() => navigate('/login')}
                  variant="ghost"
                  className="text-gray-300 hover:text-white hover:bg-gray-900"
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  Login
                </Button>
                <Button
                  onClick={() => navigate('/signup')}
                  className="bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-500/20"
                >
                  Sign Up
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </motion.header>
  );
};

export default Header;
