
import React from 'react';
import { Calendar, Package, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const SubscriptionsSection = ({ subscriptions }) => {
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (!subscriptions || subscriptions.length === 0) {
    return (
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-8 text-center">
        <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
          <Package className="w-8 h-8 text-gray-600" />
        </div>
        <h3 className="text-lg font-semibold text-white mb-2">No active subscriptions</h3>
        <p className="text-gray-400 text-sm max-w-md mx-auto">
          You don't have any active software subscriptions yet. Visit the software selector to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {subscriptions.map((sub, index) => (
        <motion.div
          key={sub.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:shadow-xl hover:shadow-orange-500/5 hover:border-gray-700 transition-all duration-300 group"
        >
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-bold text-white group-hover:text-orange-400 transition-colors">
                {sub.software_name}
              </h3>
              <p className="text-sm text-gray-400">{sub.plan}</p>
            </div>
            <span
              className={cn(
                "px-2.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider",
                sub.status === 'active'
                  ? "bg-green-500/10 text-green-400 border border-green-500/20"
                  : "bg-red-500/10 text-red-400 border border-red-500/20"
              )}
            >
              {sub.status}
            </span>
          </div>

          <div className="space-y-3 border-t border-gray-800 pt-4 mt-2">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-500 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Start Date
              </span>
              <span className="text-gray-300">{formatDate(sub.start_date)}</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-500 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                End Date
              </span>
              <span className="text-gray-300">{formatDate(sub.end_date)}</span>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default SubscriptionsSection;
