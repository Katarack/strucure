
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Send, Loader2 } from 'lucide-react';

const ContactForm = () => {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    subject: '',
    message: ''
  });

  // Reset form when needed, but we don't need extensive effects here since user is stable in protected route
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!currentUser) {
      toast({
        title: "Authentication Error",
        description: "You must be logged in to send a message.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.subject.trim() || !formData.message.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all fields.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from('contacts')
        .insert({
          user_id: currentUser.id,
          email: currentUser.email,
          name: currentUser.user_metadata?.full_name || 'Authenticated User',
          subject: formData.subject,
          message: formData.message,
          created_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Message Sent",
        description: "We've received your message and will respond to your email shortly.",
        className: "bg-green-600 border-green-700 text-white",
      });

      setFormData({ subject: '', message: '' });

    } catch (err) {
      console.error('Contact submit error:', err);
      toast({
        title: "Submission Failed",
        description: err.message || "Could not send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 shadow-lg">
      <h3 className="text-xl font-bold text-white mb-4">Contact Support</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Your Email</label>
          <Input 
            value={currentUser?.email || ''} 
            disabled 
            className="bg-gray-800 border-gray-700 text-gray-400 cursor-not-allowed"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Subject</label>
          <Input 
            placeholder="How can we help?"
            value={formData.subject}
            onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
            className="bg-gray-950 border-gray-700 text-white focus:border-orange-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">Message</label>
          <Textarea 
            placeholder="Describe your issue or question..."
            value={formData.message}
            onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
            className="bg-gray-950 border-gray-700 text-white focus:border-orange-500 min-h-[120px]"
            required
          />
        </div>

        <Button 
          type="submit" 
          disabled={isSubmitting}
          className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Sending...
            </>
          ) : (
            <>
              Send Message
              <Send className="w-4 h-4 ml-2" />
            </>
          )}
        </Button>
      </form>
    </div>
  );
};

export default ContactForm;
