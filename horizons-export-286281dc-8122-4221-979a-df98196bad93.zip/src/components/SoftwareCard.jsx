
import React from 'react';
import { motion } from 'framer-motion';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowRight, Lock } from 'lucide-react';

const SoftwareCard = ({ software, isSelected, onToggle }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleAccess = (e) => {
    e.stopPropagation(); // Prevent card selection toggle when clicking button

    if (user) {
      // User is authenticated: proceed to checkout with this item
      navigate('/checkout', { state: { selectedSoftware: [software.id] } });
    } else {
      // User is NOT authenticated: redirect to login
      navigate('/login', { state: { from: location.pathname } });
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -4 }}
      transition={{ duration: 0.2 }}
      className={`bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-6 border-2 transition-all duration-300 relative group ${
        isSelected ? 'border-orange-500 shadow-lg shadow-orange-500/20' : 'border-gray-700 hover:border-orange-400'
      }`}
      onClick={() => onToggle(software.id)}
    >
      <div className="flex items-start gap-4">
        <Checkbox
          checked={isSelected}
          onCheckedChange={() => onToggle(software.id)}
          className="mt-1 data-[state=checked]:bg-orange-500 data-[state=checked]:border-orange-500"
        />
        <div className="flex-1">
          <h3 className="text-xl font-bold text-white mb-2">{software.name}</h3>
          <p className="text-gray-400 text-sm mb-4 min-h-[40px]">{software.description}</p>
          <div className="flex items-center justify-between mb-4">
            <span className="text-2xl font-bold text-orange-500">${software.price.toFixed(2)}/mo</span>
            <span className="text-xs text-gray-500 bg-gray-800 px-3 py-1 rounded-full border border-gray-700">
              {software.category}
            </span>
          </div>

          <Button
            onClick={handleAccess}
            className="w-full bg-white/5 hover:bg-orange-500 text-gray-300 hover:text-white border border-gray-700 hover:border-orange-500 transition-all duration-300"
            size="sm"
          >
            {user ? (
              <span className="flex items-center gap-2">
                Get License <ArrowRight className="w-4 h-4" />
              </span>
            ) : (
              <span className="flex items-center gap-2">
                Access <Lock className="w-3 h-3" />
              </span>
            )}
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default SoftwareCard;
