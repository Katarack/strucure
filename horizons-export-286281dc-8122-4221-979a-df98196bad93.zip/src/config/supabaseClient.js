
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://dqinyogpwbayylxhiqxz.supabase.co';
const supabaseAnonKey = 'sb_publishable__T7X6VE5QHM3ueMM57Cv9Q_oPWH-2jU';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase credentials are missing.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
